﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoCSharpBase
{
    enum Categorie
    {

        MEUBLE = 2,
        LEGUME,
        FRUIT = 3,
        ELECTRONIQUE

    }
}
